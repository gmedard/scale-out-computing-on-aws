========
Instructions: https://awslabs.github.io/scale-out-computing-on-aws/
========
Web Based Installer: https://github.com/mcrozes/soca-web-based-installer

(Base Install) For a new install, use "scale-out-computing-on-aws.template"
(Advanced Install) To install SOCA on an existing environments (VPC, Subnets...), use "install-with-existing-resources.template"
